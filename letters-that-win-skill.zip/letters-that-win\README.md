# Letters That Win - Sales Letter Writing Skill

Classic copywriting and sales letter writing techniques from A.W. Shaw's "How to Write Letters that Win". Timeless principles for persuasive letter writing applicable to modern email marketing, landing pages, and direct response copywriting.

## Overview

**"A letter that wins is a letter that gets read and acted upon."**

The fundamental principle: Every letter must earn the right to be read, then earn the right to get a response.

## What's Included

- **5-Part Letter Structure** - Complete framework for winning letters
- **21 Rules of Winning Letters** - Mental, structural, and psychological guidelines
- **The P.S. Power** - Using postscripts effectively
- **Modern Applications** - Email, landing pages, VSL scripts
- **Quick-Start Formula** - "Mad Libs" template for immediate use
- **Common Mistakes** - What to avoid in sales writing

## File Structure

```
letters-that-win/
├── SKILL.md                    # Main skill file with complete framework
└── README.md                   # This file
```

## Installation

1. Download or clone this repository
2. Copy the entire `letters-that-win` folder to your OpenClaw workspace:
   ```
   ~/.openclaw/workspace/skills/letters-that-win/
   ```
3. Restart OpenClaw Gateway
4. The skill is now available for use

## Usage

In your OpenClaw session, simply ask about:
- Writing sales letters or emails
- Creating landing page copy
- Crafting fundraising appeals
- Writing direct mail pieces
- Creating VSL (Video Sales Letter) scripts
- Any persuasive business communication

## Core Framework: 5-Part Letter Structure

### 1. THE HEADLINE / OPENING (The Hook)
**Purpose:** Stop the reader and make them want to read more.

**Techniques:**
- **News Headline:** "At last - a way to [solve problem] without [common difficulty]"
- **Question Opening:** "Are you making this costly mistake in your [business/life]?"
- **Direct Benefit:** "Here's how to [desired result] in [timeframe]"
- **Curiosity Gap:** "I wish I had known this 5 years ago..."

### 2. THE OPENING PARAGRAPH (The Transition)
**Purpose:** Bridge from headline to body, establish credibility.

**Approaches:**
- **Story Opening:** "Three months ago, I was in the same position you are now..."
- **Problem Agitation:** "You know the frustration of [problem]. You've tried..."
- **Direct Statement:** "I'm writing to tell you about a remarkable discovery..."

### 3. THE BODY (The Proof & Benefits)
**Purpose:** Build desire and prove your claims.

**Structure:**
1. Present the Solution
2. Prove It Works (testimonials, case studies)
3. List Benefits (not features)
4. Handle Objections

**Feature-to-Benefit Translation:**
| Feature | Benefit |
|---------|---------|
| Made of steel | Lasts a lifetime - never buy another |
| 24-hour service | Peace of mind - we're there when you need us |
| Proven formula | Results guaranteed - or your money back |

### 4. THE OFFER (The Terms)
**Purpose:** Make it easy to say yes.

**Elements:**
- Clear Price
- Risk Reversal (guarantee)
- Bonuses (high perceived value)
- Payment Terms

**Guarantee Formulas:**
- "If not completely satisfied, return within 30 days for full refund"
- "Try it for 30 days - if you don't [get result], it's free"
- "Double your money back if it doesn't work"

### 5. THE CLOSE (The Call to Action)
**Purpose:** Compel immediate action.

**Elements:**
1. Direct Command - Tell them exactly what to do
2. Reason to Act Now - Create urgency
3. Restate the Benefit - Remind them what they gain

**Urgency Techniques:**
- Scarcity: "Only 500 copies available"
- Deadline: "Offer expires Friday at midnight"
- Fast-Action Bonus: "First 100 respondents receive [bonus]"

## The 21 Rules of Winning Letters

### Mental Preparation
1. Write to ONE person
2. Have a definite purpose
3. Believe in what you're selling

### Structure & Flow
4. Get attention first
5. Create interest quickly
6. Build desire
7. Make them act

### Writing Style
8. Use simple words
9. Use short sentences
10. Use "you" more than "I"
11. Be specific ("$1,247" not "over $1,000")
12. Tell the truth - but make it fascinating

### Psychological Triggers
13. Appeal to self-interest
14. Create pictures in the mind
15. Use stories (Facts tell, stories sell)
16. Handle objections
17. Prove every claim

### The Offer
18. Make it risk-free
19. Make it easy to order
20. Create urgency
21. Ask for the order

## The P.S. Power

**The P.S. is the second most-read part of any letter (after the headline).**

**Uses:**
1. Restate the main benefit
2. Add urgency
3. Add a new point
4. Reinforce guarantee

## Modern Applications

### Email Marketing
- Subject Line = Headline
- Preview Text = Opening
- Body = Body
- CTA Button = Close

### Landing Pages
- Hero Headline = Letter Headline
- Subheadline = Opening Paragraph
- Bullets = Body Benefits
- Form/CTA = Close

### Video Sales Letters (VSL)
- First 3 seconds = Headline
- Hook = Opening
- Content = Body
- Pitch = Offer + Close

## Quick-Start Formula (Mad Libs Template)

```
HEADLINE: At Last! [Solution] Without [Common Problem]

Dear [Name],

If you're tired of [pain point], then this will be the most 
important letter you read this year.

Here's why: [Brief story or proof]

• [Bullet of benefit 1]
• [Bullet of benefit 2]  
• [Bullet of benefit 3]

And the best part? [Risk reversal/Guarantee]

To get started, simply [clear action]. 

But don't delay - [urgency reason].

Sincerely,
[Name]

P.S. [Restate strongest benefit or urgency]
```

## Common Mistakes to Avoid

1. Starting with "I" instead of "you"
2. Being vague instead of specific
3. Focusing on features instead of benefits
4. No clear call to action
5. No urgency
6. Too long without breaks (use subheads, bullets)
7. Ignoring objections
8. Weak guarantee

## When to Use This Skill

Use this skill when:
- Writing sales letters or emails
- Creating landing page copy
- Crafting fundraising appeals
- Writing direct mail pieces
- Creating VSL scripts
- Writing any persuasive business communication

**Remember: The principles never change - only the medium.**

## Credits

Based on A.W. Shaw's classic "How to Write Letters that Win"

## License

This skill is provided as-is for educational and practical use with OpenClaw AI agents.
