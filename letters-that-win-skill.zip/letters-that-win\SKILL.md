---
name: letters-that-win
description: Classic copywriting and sales letter writing techniques from A.W. Shaw's "How to Write Letters that Win". Use when crafting persuasive business letters, sales letters, fundraising appeals, or any written communication designed to get results. Covers attention-grabbing openings, building desire, creating urgency, and closing for action. Applicable to modern email marketing, landing pages, and direct response copywriting.
---

# Letters That Win - Sales Letter Writing Framework

A skill based on A.W. Shaw's classic "How to Write Letters that Win" - timeless principles of persuasive letter writing that apply equally to modern email marketing, sales pages, and direct response copy.

## Core Philosophy

**"A letter that wins is a letter that gets read and acted upon."**

The fundamental principle: Every letter must earn the right to be read, then earn the right to get a response.

---

## The 5-Part Letter Structure

### 1. THE HEADLINE / OPENING (The Hook)
**Purpose:** Stop the reader and make them want to read more.

**Techniques:**
- **News Headline:** Present something newsworthy
  - "At last - a way to [solve problem] without [common difficulty]"
  
- **Question Opening:** Ask something that hits a pain point
  - "Are you making this costly mistake in your [business/life]?"
  
- **Direct Benefit:** Lead with the strongest benefit
  - "Here's how to [desired result] in [timeframe]"
  
- **Curiosity Gap:** Create information gap
  - "I wish I had known this 5 years ago..."

**Rules:**
- Must be relevant to the reader
- Must promise a benefit or arouse curiosity
- Must be specific, not vague
- Avoid cleverness at the expense of clarity

---

### 2. THE OPENING PARAGRAPH (The Transition)
**Purpose:** Bridge from headline to body, establish credibility, and keep them reading.

**Approaches:**
- **Story Opening:** "Three months ago, I was in the same position you are now..."
- **Problem Agitation:** "You know the frustration of [problem]. You've tried [solutions] but..."
- **Direct Statement:** "I'm writing to tell you about a remarkable discovery..."

**Key:** The first paragraph must flow naturally from the headline and create momentum.

---

### 3. THE BODY (The Proof & Benefits)
**Purpose:** Build desire and prove your claims.

**Structure:**
1. **Present the Solution** - What you offer
2. **Prove It Works** - Testimonials, case studies, facts
3. **List Benefits** - Not features, but what they get
4. **Handle Objections** - Address concerns before they arise

**The Feature-to-Benefit Translation:**
| Feature | Benefit |
|---------|---------|
| Made of steel | Lasts a lifetime - never buy another |
| 24-hour service | Peace of mind - we're there when you need us |
| Proven formula | Results guaranteed - or your money back |

**Persuasion Techniques:**
- **Specificity:** Use exact numbers, not round ones
  - "Saved $1,247 in the first month" not "saved over $1,000"
  
- **Social Proof:** Testimonials, user counts, endorsements
  - "Used by over 50,000 businesses"
  
- **Contrast:** Before/after, with/without
  - "Before: Struggling with [problem]. After: Enjoying [benefit]"

---

### 4. THE OFFER (The Terms)
**Purpose:** Make it easy to say yes.

**Elements of a Winning Offer:**
1. **Clear Price** - Or clear path to get price
2. **Risk Reversal** - Guarantee that removes fear
3. **Bonuses** - Additional value (low cost to you, high perceived value)
4. **Payment Terms** - Make it affordable

**Guarantee Formulas:**
- "If not completely satisfied, return within 30 days for full refund"
- "Try it for 30 days - if you don't [get result], it's free"
- "Double your money back if it doesn't work"

---

### 5. THE CLOSE (The Call to Action)
**Purpose:** Compel immediate action.

**Elements:**
1. **Direct Command:** Tell them exactly what to do
   - "Fill out the enclosed card and mail it today"
   - "Click the button below and complete your order"
   
2. **Reason to Act Now:** Create urgency
   - Limited quantity
   - Deadline approaching
   - Special bonus for quick response
   
3. **Restate the Benefit:** Remind them what they gain
   - "Don't delay - start enjoying [benefit] today"

**Urgency Techniques:**
- **Scarcity:** "Only 500 copies available"
- **Deadline:** "Offer expires Friday at midnight"
- **Fast-Action Bonus:** "First 100 respondents receive [bonus]"

---

## The 21 Rules of Winning Letters

### Mental Preparation
1. **Write to ONE person** - Picture your ideal reader
2. **Have a definite purpose** - Know exactly what action you want
3. **Believe in what you're selling** - Enthusiasm is contagious

### Structure & Flow
4. **Get attention first** - Or nothing else matters
5. **Create interest quickly** - Don't waste the reader's time
6. **Build desire** - Show them what they gain
7. **Make them act** - Don't hope they'll respond - make them

### Writing Style
8. **Use simple words** - Write to be understood, not to impress
9. **Use short sentences** - Easy to read, hard to put down
10. **Use "you" more than "I"** - It's about them, not you
11. **Be specific** - "$1,247" beats "over $1,000"
12. **Tell the truth** - But make it fascinating

### Psychological Triggers
13. **Appeal to self-interest** - Everyone asks "What's in it for me?"
14. **Create pictures in the mind** - Make them see the benefits
15. **Use stories** - Facts tell, stories sell
16. **Handle objections** - Address doubts before they arise
17. **Prove every claim** - Back up statements with evidence

### The Offer
18. **Make it risk-free** - Remove the fear of buying
19. **Make it easy to order** - Simple forms, clear instructions
20. **Create urgency** - Give a reason to act now
21. **Ask for the order** - Don't be timid about closing

---

## The P.S. Power

**The P.S. is the second most-read part of any letter (after the headline).**

**Uses:**
1. **Restate the main benefit:** "P.S. Remember, you get [benefit] guaranteed"
2. **Add urgency:** "P.S. The bonus expires Friday - don't miss out"
3. **Add a new point:** "P.S. I forgot to mention..."
4. **Reinforce guarantee:** "P.S. You risk nothing with our double guarantee"

---

## Modern Applications

### Email Marketing
- **Subject Line = Headline**
- **Preview Text = Opening**
- **Body = Body**
- **CTA Button = Close**

### Landing Pages
- **Hero Headline = Letter Headline**
- **Subheadline = Opening Paragraph**
- **Bullets = Body Benefits**
- **Form/CTA = Close**

### Video Sales Letters (VSL)
- **First 3 seconds = Headline**
- **Hook = Opening**
- **Content = Body**
- **Pitch = Offer + Close**

---

## Common Mistakes to Avoid

1. **Starting with "I"** - Start with "you" or a benefit
2. **Being vague** - Specifics build credibility
3. **Focusing on features** - Sell benefits, not features
4. **No clear call to action** - Tell them exactly what to do
5. **No urgency** - Give a reason to act now
6. **Too long without breaks** - Use subheads, bullets, white space
7. **Ignoring objections** - Address concerns proactively
8. **Weak guarantee** - Strong guarantees increase sales

---

## Quick-Start Formula

**The "Mad Libs" Sales Letter:**

```
HEADLINE: At Last! [Solution] Without [Common Problem]

Dear [Name],

If you're tired of [pain point], then this will be the most 
important letter you read this year.

Here's why: [Brief story or proof]

[Bullet of benefit 1]
[Bullet of benefit 2]  
[Bullet of benefit 3]

And the best part? [Risk reversal/Guarantee]

To get started, simply [clear action]. 

But don't delay - [urgency reason].

Sincerely,
[Name]

P.S. [Restate strongest benefit or urgency]
```

---

## When to Use This Skill

Use this skill when:
- Writing sales letters or emails
- Creating landing page copy
- Crafting fundraising appeals
- Writing direct mail pieces
- Creating VSL scripts
- Writing any persuasive business communication

Remember: **The principles never change - only the medium.**
