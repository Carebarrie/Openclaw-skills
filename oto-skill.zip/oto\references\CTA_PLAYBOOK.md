# Call to Action (CTA) Playbook

## Overview
CTAs are the bridge between content and conversion. In OTO framework, there are 5 main types of CTAs, each serving different purposes in the customer journey.

## The 5 CTA Types

### 1. Empower CTA
**Definition:** Calls to action that boost confidence and inspire belief in the audience's ability to succeed.

**Psychology:**
- Addresses self-doubt
- Builds confidence
- Creates emotional connection
- Positions you as supporter/ally

**Best Used:**
- After educational content
- With inspirational content
- When audience needs motivation
- Before introducing solution

**Examples by Platform:**

*Social Media:*
- "You deserve this level of success"
- "You're ready for the next chapter"
- "This is YOUR moment"
- "You've got what it takes"

*Email:*
- "You're capable of achieving this"
- "I believe in your potential"
- "You deserve better results"

*Sales Pages:*
- "You deserve to work with the best"
- "You're worth this investment"
- "Your future self will thank you"

**Placement in Content:**
- End of educational posts
- Middle of sales pages (before offer)
- Subject lines for motivation emails
- Before introducing solution

**Success Metrics:**
- Engagement rate increase
- Positive comments
- Shares
- Lead generation

---

### 2. Engagement CTA
**Definition:** Low-commitment actions that build community and increase algorithm visibility.

**Psychology:**
- Low barrier to entry
- Social proof building
- Community feeling
- Algorithm-friendly

**Best Used:**
- Regular content (80% value posts)
- Building relationships
- Increasing reach
- Gathering insights

**Examples by Type:**

*Comment-Based:*
- "Comment 'YES' if you agree"
- "Type 'ME' if this resonates"
- "Share your experience below"
- "What's your biggest challenge? Comment below"

*Share-Based:*
- "Share this with someone who needs it"
- "Tag a friend who struggles with this"
- "Save this for later"

*Interaction-Based:*
- "Vote in the poll above"
- "React with ❤️ if you agree"
- "Double tap if this helped you"

*Question-Based:*
- "What's your biggest struggle with [topic]?"
- "How would you handle this situation?"
- "Which option do you prefer: A or B?"

**Platform-Specific Tactics:**

*Instagram:*
- "Save this post"
- "Share to your story"
- "Tag 3 friends"

*Facebook:*
- "Check in if you're watching live"
- "Invite friends to this group"
- "React with the right emoji"

*LinkedIn:*
- "Share your perspective"
- "Tag a colleague"
- "Comment your thoughts"

*YouTube:*
- "Hit the like button"
- "Subscribe and hit the bell"
- "Comment your #1 takeaway"

**Success Metrics:**
- Comments per post
- Shares
- Saves/bookmarks
- Poll participation
- Story shares

---

### 3. Sale Funnel CTA (Soft Offer)
**Definition:** Intermediate commitment actions that move prospects into your sales funnel.

**Psychology:**
- Exchange of value
- Commitment escalation
- Building reciprocity
- Lead generation

**Best Used:**
- Soft offer content (15% category)
- After building value
- When audience is warm
- Before direct pitch

**Examples by Funnel Stage:**

*Awareness Stage:*
- "Download the free checklist"
- "Get the free guide"
- "Access the free training"
- "Watch the free video series"

*Interest Stage:*
- "Join our free community"
- "Subscribe to the newsletter"
- "Take the free assessment"
- "Get the free template"

*Consideration Stage:*
- "Book a free consultation"
- "Schedule a strategy call"
- "Join the free webinar"
- "Get a free audit"

**Lead Magnet Types:**

*Educational:*
- Ebooks
- Guides
- Checklists
- Templates
- Cheat sheets

*Interactive:*
- Quizzes
- Assessments
- Calculators
- Tools

*Access-Based:*
- Free trials
- Demo access
- Community membership
- Newsletter

**Best Practices:**
- Make it truly valuable
- Easy to consume
- Related to paid offer
- Immediate delivery
- Clear next steps

**Success Metrics:**
- Opt-in rate
- Lead quality
- Email open rates
- Funnel progression

---

### 4. Closing CTA (Direct Sale)
**Definition:** Direct purchase or commitment actions for immediate sales.

**Psychology:**
- Urgency/scarcity
- Clear decision point
- Remove barriers
- Action-oriented

**Best Used:**
- Direct sales content (5% category)
- After full value demonstration
- When prospect is ready
- Limited time offers

**Examples by Urgency Type:**

*Scarcity-Based:*
- "Only 5 spots left - apply now"
- "Limited to 20 people"
- "Closing applications soon"
- "Waitlist only after this"

*Time-Based:*
- "Offer ends tonight at midnight"
- "Price increases tomorrow"
- "Last chance - 24 hours left"
- "Early bird ends Friday"

*Action-Based:*
- "Click here to buy now"
- "Apply for your spot"
- "Secure your place"
- "Claim your bonus"

**Closing Formulas:**

*Direct:*
"Click the link in bio to get started"

*Benefit-focused:*
"Start getting results today - buy now"

*Urgency-focused:*
"Don't miss out - only 3 left"

*Risk-reversal:*
"Try it risk-free - 30-day guarantee"

**Platform-Specific:**

*Email:*
- "Click here to claim your spot"
- "Reply to this email to get started"
- "Hit reply with 'YES' to join"

*Sales Page:*
- Big, prominent buttons
- Multiple CTAs throughout
- "Add to Cart" 
- "Buy Now"

*Social Media:*
- "Link in bio"
- "DM me 'INFO' for details"
- "Click the link below"

**Success Metrics:**
- Conversion rate
- Revenue per CTA
- Cart abandonment rate
- Average order value

---

### 5. Special Offer CTA
**Definition:** Promotional CTAs that create urgency through limited-time deals or bonuses.

**Psychology:**
- Fear of missing out (FOMO)
- Increased perceived value
- Urgency
- Exclusivity

**Best Used:**
- Product launches
- Seasonal promotions
- Flash sales
- Special events

**Examples by Offer Type:**

*Discount-Based:*
- "30% off - today only"
- "Flash sale: 50% off for 24 hours"
- "Use code SAVE20 for 20% off"
- "Black Friday special pricing"

*Bonus-Based:*
- "Free bonus expires in 24 hours"
- "Get $2,000 in bonuses free"
- "Bonus stack available until midnight"
- "First 10 get exclusive bonus"

*Bundle-Based:*
- "Buy one, get one free"
- "Complete package deal"
- "All-access pass limited time"
- "Bundle and save $500"

*Payment-Based:*
- "No payments for 30 days"
- "Payment plan ends tomorrow"
- "0% financing available now"

**Creating Effective Special Offers:**

1. **Clear Value**
   - State exact savings
   - List bonuses with values
   - Show before/after price

2. **Real Urgency**
   - Actual deadline
   - Limited quantity
   - Genuine scarcity

3. **Easy Action**
   - Simple checkout
   - Clear instructions
   - No friction

**Success Metrics:**
- Response rate
- Revenue generated
- Average deal size
- New customer acquisition

---

## CTA Strategy by Content Type

### Educational Content (80%)
**Primary CTA:** Engagement
**Secondary CTA:** Sale Funnel (soft)

Example flow:
1. Post educational content
2. CTA: "Comment your biggest takeaway"
3. Follow-up DM: "Want the full guide? Link in bio"

### Soft Offer Content (15%)
**Primary CTA:** Sale Funnel
**Secondary CTA:** Engagement

Example flow:
1. Value + soft pitch
2. CTA: "Download the free template"
3. Follow-up: "Want personalized help? Book a call"

### Direct Sales Content (5%)
**Primary CTA:** Closing
**Secondary CTA:** Special Offer

Example flow:
1. Full pitch with proof
2. CTA: "Only 5 spots - apply now"
3. Urgency: "Bonus expires tonight"

---

## CTA Optimization

### A/B Testing Elements:
1. **Button text**
   - "Buy Now" vs "Get Started"
   - "Apply" vs "Join"

2. **Color and design**
   - Button color
   - Size and placement
   - Contrast

3. **Urgency elements**
   - Countdown timers
   - Stock counters
   - Deadline text

4. **Risk reversal**
   - Guarantee mention
   - "No credit card required"
   - "Cancel anytime"

### Best Practices:

1. **One Primary CTA**
   - Don't confuse with multiple options
   - Make the main action clear

2. **Above the Fold**
   - Visible without scrolling
   - Multiple CTAs on long pages

3. **Action-Oriented Language**
   - Use verbs
   - Be specific
   - Create urgency

4. **Match Intent**
   - Cold traffic → Engagement/Sale Funnel
   - Warm traffic → Sale Funnel/Closing
   - Hot traffic → Closing/Special Offer

---

## CTA Mistakes to Avoid

1. **Too Many CTAs**
   - Confuses the audience
   - Dilutes focus
   - Reduces conversion

2. **Weak Language**
   - "Click here"
   - "Learn more"
   - Be specific and compelling

3. **Wrong Timing**
   - Pitching too early
   - Not asking for sale when ready
   - Misreading audience temperature

4. **No Urgency**
   - "Whenever you're ready"
   - No reason to act now
   - Missing FOMO

5. **Hidden CTAs**
   - Too small
   - Poor contrast
   - Buried in text

---

## CTA Performance Tracking

### Key Metrics:
1. **Click-Through Rate (CTR)**
2. **Conversion Rate**
3. **Revenue per CTA**
4. **Time to Conversion**

### Tracking Setup:
- UTM parameters
- Unique landing pages
- Conversion pixels
- Heat maps

### Review Frequency:
- Daily: High-traffic CTAs
- Weekly: Regular content
- Monthly: Overall strategy
