# OTO Framework - Detailed Reference

## The Complete OTO System

### Origins
OTO Framework was developed by BigLeap for online marketing and high-ticket sales. It emphasizes building authority first, then making strategic offers.

## 7 Steps to Facebook/Social Media Success

From Module 2, the framework for building a successful selling page:

### Step 1: Set Clear Goals
- Open a page and set a goal right away
- Goal: Must become famous on social media
- Have a clear vision from day one

### Step 2: Focus 100% Online
- Treat online as MAIN work, not a side job
- Full commitment required for success
- Online business deserves full attention

### Step 3: Create a "Mango Page" (ถั่วงอก vs มะม่วง)

**คำอธิบายจากผู้สอน:**
เปรียบเทียบระหว่าง **ถั่วงอก (Sprout)** vs **มะม่วง (Mango)**

**ถั่วงอก (Sprout Page) ❌:**
- โตไว แต่ตายไว
- ทำแบบสั้นๆ ไม่มีความเชี่ยวชาญจริงๆ
- เอาแต่ขายของอย่างเดียว
- ตีหัวเข้าบ้านแล้วเลิก
- ไม่มีเนื้อหาความรู้ให้คุณค่าลูกค้า

**มะม่วง (Mango Page) ✅:**
- ใช้เวลาปลูกนาน ต้องมีความรู้ความชำนาญ
- ต้องใส่ใจดูแล
- พอออกลูกแล้ว มีผลให้เก็บกินระยะยาว
- เน้นความเชี่ยวชาญในสินค้าและบริการจริงๆ
- ลูกค้าซื้อเพราะเชื่อใจในความเชี่ยวชาญของเรา

**วิธีสร้าง Mango Page:**
- ลบทุกอย่างที่ไม่เกี่ยวข้องกับ niche
- Focus เฉพาะ specialty ที่เราเชี่ยวชาญจริงๆ
- ไม่พยายามขายทุกอย่างให้ทุกคน
- สร้าง expertise ที่ลูกค้าเชื่อถือได้

### Step 4: Showcase Your Strengths
- Bring out your unique selling points (USP) to the FRONT
- Page name must communicate value
- Cover photo must show expertise/professionalism
- Don't hide your strengths "behind the shop"

### Step 5: Build Expert-Level Page (80|15|5)
- Apply the 80-15-5 content ratio
- Page Level 4 (Expert Level)
- Make customers come TO YOU (attraction marketing)

### Step 6: Gradually Level Up
- Start from Page Level 2
- Progress systematically to Level 4
- Those with good products see results quickly with small adjustments

### Step 7: Grow with Short Videos
- Use TikTok Reels/Shorts for rapid growth
- Short-form video is essential
- Act quickly before the trend passes

## Page Level Framework

### Page Level 2: ถั่วงอก (ขายอย่างเดียว) ❌
- เน้นทำ content ขายเป็นส่วนใหญ่
- เน้นคอนเทนที่แจ้งโปรโมชั่น
- เน้นให้ทักมาซื้อ
- คอนเทนให้ความรู้หรือแสดงความเชี่ยวชาญแทบไม่มีเลย
- รีวิวจากลูกค้าน้อยหรือไม่มี
- ขายขายขาย ไม่มีคุณค่าให้ลูกค้า

### Page Level 4: มะม่วง (ให้ความรู้ + รีวิว) ✅
- แทบไม่มีคอนเทนขายตรงๆ เลย
- เน้นให้ความรู้เป็นหลัก
- เน้นวิธีการแก้ pain point ของลูกค้า
- มีรีวิวจากผู้ใช้จริง (testimonials)
- ทำคอนเทนคุณค่าให้ลูกค้าเชื่อใจ
- ลูกค้าตั้งใจมาซื้อกับผู้รู้เรื่องนี้จริงๆ
- ลูกค้ามาหาเราเอง (attraction marketing)

### การอัพเกรดจาก Level 2 → Level 4:
- ค่อยๆ ลดคอนเทนขายลง
- เพิ่มคอนเทนให้ความรู้
- สะสมรีวิวและ testimonials
- สร้าง credibility ให้ชัดเจน
- ใช้เวลาและความสม่ำเสมอ

## Key Marketing Concepts from Visual Materials

### Moment of Truth
**Definition:** The critical moment when customers decide whether to trust you or not.

**Application:**
- Brands must compete to prove authenticity
- This is when you demonstrate "we are the real deal"
- Happens at every customer touchpoint
- Critical for conversion

**How to Win:**
- Show real results
- Display testimonials
- Demonstrate expertise
- Be transparent

### Instant Authority Principle
**Core Idea:** Don't hide your strengths—showcase them prominently.

**Wrong Approach:**
- Hiding good qualities "behind the shop"
- Being humble to the point of invisibility
- Not communicating value clearly

**Right Approach:**
- Bring your strengths to the FRONT
- Display credentials prominently
- Show what makes you different
- Make it immediately visible

### The "Who" Factor (Credibility First)
**Critical Insight:** No matter how well-written your content is, if the audience doesn't know WHO is speaking, they won't believe you.

**Implications:**
- Personal branding is foundational
- Establish credibility BEFORE giving advice
- The messenger matters as much as the message
- Without trust, good content becomes meaningless

**Implementation:**
- Clear author/expert identity
- Visible credentials and background
- Consistent personal brand
- Social proof displayed prominently

### Content That Solves Problems
**Key Insight:** Content that "hits the mark" makes customers see you as an expert in their minds.

**Formula:**
```
Effective Content = Problem-Solving + Expert Positioning
```

**Characteristics:**
- Addresses real customer pain points
- Provides actionable solutions
- Demonstrates deep understanding
- Positions creator as go-to expert

### 24/7 Availability Advantage
**Old Way:**
- Wait for customers to walk in
- Limited by business hours
- Geography-dependent

**New Way (Digital):**
- Customers can reach you 24 hours a day
- Anywhere, anytime access
- No geographical limitations
- Always-open "digital storefront"

**Implementation:**
- Automated systems
- Chatbots for initial contact
- Clear response time expectations
- Digital assets working while you sleep

### Teasing Content Strategy (Module 10)
**Concept:** การยั่ว (Tease) ให้คนอยากได้ ก่อนที่จะขาย

**ดูเพิ่มเติมที่:** [GTA-IT Themes](#theme-deep-dive) — โดยเฉพาะ 4 Themes:
1. Fun/Entertainment
2. Education  
3. Inspiration
4. Transformation

**วิธี Tease ที่ถูกต้อง:**
- โชว์ผลลัพธ์ที่น่าอยากได้ (desirable outcome)
- สร้าง FOMO (Fear Of Missing Out)
- สร้างความคาดหวัง (anticipation)
- ทำให้คน WANT ก่อน ค่อยขายทีหลัง
- ใช้ Content ตาม Themes ที่เหมาะสมกับ target audience

### Non-Selling Sales Posts (ขายแบบไม่เหมือนขาย)

**คำอธิบายจากผู้สอน:**
การขายที่ไม่มีโปรโมชั่น ไม่ลดราคา ไม่มีของแถม และตั้งราคาสูงกว่าตลาด แต่ลูกค้าก็ยังซื้อ

**หลักการ:**
- ไม่มีโปรโมชั่น
- ไม่ลดราคา
- ไม่มีของแถม
- ตั้งราคาสูงกว่าตลาดทั่วไป
- แต่ลูกค้าก็ยังซื้อ!

**ทำได้อย่างไร:**
- แสดงความเชี่ยวชาญผ่านคลิปวีดีโอหรือโพสต์คอนเทนต์
- เน้นให้ความรู้ ให้คุณค่า
- แก้ pain point ของลูกค้าจนพวกเขาเห็นว่าเราเก่งจริง
- คนที่เข้ามาเชื่อในความเชี่ยวชาญของเรา
- ทักมาซื้อเองโดยที่ไม่มีการต่อราคา
- มั่นใจในคุณภาพและบริการของเรา
- อยากได้เองโดยที่ไม่ต้องเชียร์ให้ซื้อเลย

**ต่างจากการขายทั่วไป:**
| การขายทั่วไป | Non-Selling Sales |
|-------------|-------------------|
| ลดราคา มีโปร | ไม่ลด ไม่มีโปร |
| เชียร์ให้ซื้อ | ให้ความรู้ก่อน |
| ต่อราคาได้ | ไม่ต่อราคา |
| แข่งขันราคา | แข่งขันความเชี่ยวชาญ |
| ลูกค้าซื้อเพราะถูก | ลูกค้าซื้อเพราะเชื่อใจ |

### Thank Economy Deep Dive (Module 13)

**Core Philosophy:** Ways to add endless customers and grow sustainably.

**ความหมายที่ถูกต้อง:**
การให้ลูกค้าในแบบที่ **เกินความคาดหวังของเขา** แต่ต้อง **ไม่ขาดทุน** (ไม่ใช่การชดเชยความผิดพลาดของเรา)

**Warning:** ถ้าไม่เข้าใจอันนี้ การตลาดและการขายที่ดีทั้งหมดอาจพังทลายได้ทันที

**What Thank Economy IS:**
- ให้คุณค่าเกินที่ลูกค้าจ่าย
- ประสบการณ์ที่ดีกว่าที่คาดหวัง
- ความใส่ใจที่ลูกค้าไม่คาดคิด
- สร้าง "Wow moment" ให้ลูกค้า

**What Thank Economy is NOT:**
- ไม่ใช่การชดเชยความผิดพลาดของตัวเอง
- ไม่ใช่การทำให้ตัวเองขาดทุน
- ไม่ใช่การแก้ปัญหาที่เราทำพังเอง

**ตัวอย่างที่ถูกต้อง (Thank Economy):**
- ลูกค้าซื้อส้ม 1 กล่อง → ส่งของถึงเร็วกำหนด + แถมสูตรน้ำส้มปั่นพรีเมี่ยม
- ลูกค้าซื้อคอร์สออนไลน์ → ได้รับ surprise bonus ที่ไม่ได้ระบุใน sales page

**ตัวอย่างที่ไม่ใช่ Thank Economy (แต่เป็นการแก้ไขความผิดพลาด):**
- ลูกค้าสั่งส้ม แต่กล่องขาดจากการขนส่งของเรา → ส่งของใหม่ให้ + ให้ของเก่าไปด้วย
  - อันนี้เป็น **การแก้ไขความผิดพลาด** ไม่ใช่ Thank Economy
  - ถ้าไม่ทำแบบนี้ ลูกค้าจะเสียหาย เพราะเป็นความผิดของเรา

**Key Principle:**
Thank Economy = ให้เกินความคาดหวัง แต่เราต้องไม่ขาดทุน
การแก้ไขความผิดพลาด = ต้องทำเพื่อรับผิดชอบ ไม่ใช่ Thank Economy

### Customer Review Management
**Best Practices from Examples:**

**Review Response Template:**
1. Thank the customer
2. Acknowledge their feedback
3. Add personal blessing/wish
4. Professional but warm tone

**Example:**
- Customer: "Fast delivery, boyfriend really likes it, says it's beautiful"
- Seller: "Thank you very much customer, wishing you prosperity to buy shirts and happiness"

**Benefits:**
- Builds trust with potential customers
- Shows you care about customers
- Creates positive brand image
- Encourages more reviews

## Deep Dive: GTA Methodology

### Goal Setting Framework
**Types of Goals:**
1. **Traffic Goals** - Reach, impressions, followers
2. **Engagement Goals** - Likes, comments, shares
3. **Lead Goals** - Opt-ins, inquiries
4. **Sales Goals** - Revenue, conversions
5. **Authority Goals** - Recognition, positioning

**SMART Goals for OTO:**
- Specific: "Generate 100 leads"
- Measurable: Trackable metrics
- Achievable: Realistic based on resources
- Relevant: Aligned with business objectives
- Time-bound: "In the next 30 days"

### Theme Deep Dive (GTA-IT Themes for Teasing)

การยั่ว (Tease) ให้คนอยากได้ ทำได้ผ่าน 4 Content Themes:

---

#### T1: Fun/Entertainment Theme
**ยั่วให้อยาก ด้วยความบันเทิง**

**When to use:**
- Building initial audience
- Breaking through noise
- Humanizing brand
- ดึงดูดสายตาในครั้งแรก

**Content types:**
- Behind-the-scenes
- Humor/relatable content
- Trending topics
- Light educational content
- คอนเทนต์ที่ทำให้ยิ้ม หรือสนุก

**Best platforms:** TikTok, Instagram Reels, YouTube Shorts

---

#### T2: Education Theme
**ยั่วให้อยาก ด้วยการให้ความรู้**

**แบ่งเป็น 3 รูปแบบ:**

**2.1 ยั่วด้วยอารมณ์ (Emotion)**
- ทอดปลา
- กินจ๊าบ
- เสื้อผ้า
- อาหารที่น่ากิน
- สินค้าที่เห็นแล้วอยากได้ทันที

**2.2 ยั่วด้วยเหตุผล (เปลี่ยนความคิด)**

*ความเข้าใจผิด (Mis-Concept):*
- "มีใครเคยสงสัย... จริงหรือไม่?"
- แก้ความเชื่อที่ผิดๆ ที่คนส่วนใหญ่มี
- สร้าง Aha moment

*ข้อผิดพลาด (Mistake):*
- "เตือนภัย..."
- "ห้าม..."
- "รองเท้าแพงๆ อย่าเก็บนาน..."
- บอกว่าอะไรที่ไม่ควรทำ

*เทคนิค & ความรู้ที่คนทั่วไปไม่รู้ (Hot Tips/Secret):*
- แสดงถึงความเชี่ยวชาญ
- ความใส่ใจในรายละเอียด
- Secret tips ที่หาไม่ได้ที่อื่น

**2.3 ยั่วด้วยอารมณ์ + เหตุผล (Emotion + Logic)**
- ยั่วด้วยการทำน้ำพริก (เห็นแล้วอยากกิน)
- บอกว่าทำไมถึงอร่อยเป็นพิเศษ (เหตุผล)
- ผสมผสานทั้งสองอย่างให้สมดุล

**Best platforms:** YouTube, Blog, LinkedIn, Email, Facebook

---

#### T3: Inspiration Theme
**ยั่วให้อยาก ด้วยแรงบันดาลใจ**

**รูปแบบเนื้อหา:**

*Story การเปลี่ยนแปลง:*
- Story ของเราเอง
- Story ของลูกค้า
- จากร้านเล็กๆ หน้าบ้าน
- ฟิตหุ่น Before/After
- บั้นปลาย Story พลังทางธุรกิจ

*แก้ไขความเชื่อที่ว่ากัด:*
- "คุณอาจจะคิดว่าคนน้ำหนักเยอะจะดูไม่ดี... มันเป็นไปไม่ได้..."
- ทำลายข้อจำกัดที่คนคิดไว้
- เปิดมุมมองใหม่

*โอกาสใหม่ๆ, โลกใหม่, วิธีการใหม่ๆ:*
- Trend ใหม่ๆ
- วิธีคิดใหม่
- โอกาสที่คนอื่นยังไม่เห็น

**Best platforms:** Instagram, Facebook, Podcasts

---

#### T4: Transformation Theme
**ยั่วให้อยาก ด้วยการทำให้เกิดผลลัพธ์จริงๆ**

**เหมาะสำหรับ:** Expert Biz, Agency, Software

**รูปแบบเนื้อหา:**
- STS Pitch (Speak to Sell)
- Sale Page แนวนอน
- Challenge
- High-ticket offers
- Life-changing programs

**Characteristics:**
- Before/after stories ที่ชัดเจน
- Deep dives
- Comprehensive guides
- Intensive programs
- เน้นผลลัพธ์ที่วัดได้จริง

**Best platforms:** Webinars, Sales pages, Email sequences, Live sessions

---

### วิธีเลือก Theme

**ถามตัวเอง:**
1. ลูกค้า target ชอบอะไร? (บันเทิง / ความรู้ / แรงบันดาลใจ / ผลลัพธ์)
2. สินค้า/บริการเหมาะกับ Theme ไหน?
3. เป้าหมายของคอนเทนต์นี้คืออะไร?

**สูตรผสม:**
- 70% Education (สร้าง credibility)
- 20% Inspiration (สร้าง connection)
- 10% Fun (สร้าง engagement)

**Best platforms:** TikTok, Instagram Reels, YouTube Shorts

#### Theme 2: Education
**When to use:**
- Establishing expertise
- Building trust
- Lead generation

**Content types:**
- How-to tutorials
- Tips and tricks
- Industry insights
- Case studies

**Best platforms:** YouTube, Blog, LinkedIn, Email

#### Theme 3: Inspiration
**When to use:**
- Building emotional connection
- Story-based marketing
- Transformation stories

**Content types:**
- Success stories
- Personal journeys
- Overcoming obstacles
- Vision/mission content

**Best platforms:** Instagram, Facebook, Podcasts

#### Theme 4: Transformation
**When to use:**
- High-ticket sales
- Deep commitment offers
- Life-changing programs

**Content types:**
- Before/after stories
- Deep dives
- Comprehensive guides
- Intensive programs

**Best platforms:** Webinars, Sales pages, Email sequences

## Authority Building Deep Dive

### The 3 Layers of Authority

#### Layer 1: Trust
**Components:**
- Consistency (posting schedule)
- Authenticity (being real)
- Transparency (behind the scenes)
- Reliability (delivering promises)

**How to build:**
- Regular content schedule
- Honest communication
- Admitting mistakes
- Sharing real results

#### Layer 2: Authority Signals
**External validation:**
- Media mentions
- Guest appearances
- Certifications
- Awards/recognition
- Collaborations with known experts

**How to display:**
- "As featured in" badges
- Guest post portfolio
- Certification badges
- Testimonials from recognized names

#### Layer 3: Result Proof
**Types of proof:**
- Case studies
- Before/after comparisons
- Testimonials with specific results
- Data/metrics
- Client success stories

**Formula for strong proof:**
```
Before: [Specific situation]
Action: [What they did]
After: [Specific result with numbers]
```

### The Speed of Trust Framework
From Stephen M.R. Covey, adapted for OTO:

1. **Integrity** - Honesty and congruence
2. **Intent** - Genuine care for customer success
3. **Capability** - Skills and knowledge
4. **Results** - Track record of success

## The 80-15-5 Rule in Practice

### Content Calendar Example (Monthly)

**80% Value Content (24 posts):**
- 8 Educational posts
- 8 Entertainment posts  
- 8 Inspirational posts

**15% Soft Offers (4-5 posts):**
- Lead magnets
- Free resources
- Community invitations
- Soft CTAs

**5% Direct Sales (1-2 posts):**
- Direct pitch posts
- Limited time offers
- Sales page links
- "Buy now" CTAs

### Email Sequence Example (10 emails)

**Emails 1-8 (80%):**
- Welcome + value
- Educational content
- Story sharing
- Tips and strategies

**Email 9 (15%):**
- Soft offer
- Free consultation
- Lead magnet

**Email 10 (5%):**
- Direct sales pitch
- Limited time offer

## Winning Day Execution

### Morning Routine (30-60 min)
1. Check overnight metrics
2. Review calendar/priorities
3. Plan content for day
4. Set 3 main objectives

### Power Hours
**Hour 1-2: Content Creation**
- Create main content piece
- Schedule posts
- Prepare visuals

**Hour 3-4: Engagement**
- Respond to comments
- Engage with others' content
- Answer DMs
- Build relationships

**Hour 5: Offer Activities**
- Follow up with leads
- Soft pitch in conversations
- Prepare sales materials

### Evening Review (15-30 min)
1. Check day's metrics
2. What worked? What didn't?
3. Plan adjustments for tomorrow
4. Celebrate wins

## Content Takeover Tactics

### Organic Takeover Strategy
1. **Trend Jacking**
   - Monitor trending topics
   - Create relevant content quickly
   - Use trending hashtags

2. **Algorithm Optimization**
   - Post at optimal times
   - Encourage engagement
   - Use platform-specific features

3. **Collaboration**
   - Guest posts
   - Interviews
   - Takeovers

### Paid Takeover Strategy
1. **Retargeting**
   - Website visitors
   - Video viewers
   - Engaged users

2. **Lookalike Audiences**
   - Based on customers
   - Based on email list
   - Based on page engagement

3. **Interest Targeting**
   - Competitor audiences
   - Complementary interests
   - Behavioral targeting

## Thank Economy Principles

### Core Philosophy
"Give first, sell later"

### Implementation
1. **Value First**
   - Solve problems without expectation
   - Over-deliver on free content
   - Be genuinely helpful

2. **Appreciation Marketing**
   - Thank customers publicly
   - Celebrate client wins
   - Acknowledge engagement

3. **Relationship Building**
   - Personal connections
   - Remember details
   - Follow up without selling

### The Disney Land Principle
Create an experience so valuable that:
- People want to stay
- They tell others
- Price becomes secondary
- They become fans, not just customers

## Speak to Sell Methodology

### The 9-Step Sale Pitch

**1. Hook (First 30 seconds)**
- Pattern interrupt
- Bold statement
- Question
- Story opener

**2. Frame (Set expectations)**
- What they'll learn
- Why it matters
- Who it's for

**3. Story (Your journey)**
- Relatable struggle
- Turning point
- Transformation

**4. Problem (Their pain)**
- Agitate the problem
- Show you understand
- Make it emotional

**5. Solution (Your offer)**
- Introduce the solution
- Why it works
- Unique mechanism

**6. Offer (What they get)**
- Core product/service
- Bonuses
- Value stack

**7. Proof (Evidence)**
- Testimonials
- Case studies
- Results

**8. Guarantee (Risk reversal)**
- Remove risk
- Strong guarantee
- Refund policy

**9. Call to Action (Next step)**
- Clear instruction
- Urgency/scarcity
- Make it easy

### Pricing Psychology
- Anchor high, sell lower
- Payment plans
- Compare to alternatives
- Show ROI

## Call to Action Types

### 1. Empower CTA
**Purpose:** Boost confidence, inspire action

**Examples:**
- "You deserve this success"
- "You're ready for the next level"
- "This is your moment"

**When to use:** After educational content, inspiration posts

### 2. Engagement CTA
**Purpose:** Build community, increase reach

**Examples:**
- "Comment 'YES' if you agree"
- "Share your experience below"
- "Tag someone who needs this"

**When to use:** Regular content, building relationships

### 3. Sale Funnel CTA
**Purpose:** Move to next step in funnel

**Examples:**
- "Download the free guide"
- "Watch the free training"
- "Join the community"

**When to use:** Soft offer content (15% category)

### 4. Closing CTA
**Purpose:** Direct sale

**Examples:**
- "Only 5 spots left - apply now"
- "Offer ends tonight"
- "Click here to buy"

**When to use:** Direct sales content (5% category)

### 5. Special Offer CTA
**Purpose:** Create urgency for specific deal

**Examples:**
- "30% off - today only"
- "Bonus expires in 24 hours"
- "Early bird pricing ends soon"

**When to use:** Promotions, launches

## Tornado Cycle (Snowball Effect / S-Curve)

### คืออะไร?
Tornado Cycle คือ **Snowball Effect** หรือการทำ **New S-Curve** ที่ขึ้นไปเรื่อยๆ แบบ exponential (ทวีคูณ) ไม่ใช่ linear (เส้นตรง)

### ตัวอย่างที่ผู้สอนยก:
> "คุณคือค่าเฉลี่ยของคน 5 คนที่คุณใช้เวลาด้วยมากที่สุด"

- ถ้าคบเพื่อนที่มี positive thinking → ยิ่งให้กำลังใจซึ่งกันและกัน → ยิ่ง cheer up กัน → ผลลัพธ์ที่คาดไว้ก็จะเป็นจริง
- เป็นวงจรที่ขยายตัวขึ้นเรื่อยๆ เหมือน snowball ที่กลิ้งแล้วโตขึ้น

### ในแง่ยอดขาย:
- ขายขึ้นไปแรงๆ เลย ไม่ใช่ค่อยๆ ขึ้น
- ใช้ momentum จากความสำเร็จเล็กๆ สร้างความสำเร็จใหญ่ๆ
- ขยายตัวแบบทวีคูณ ไม่ใช่บวกทีละนิด

### Rapid Execution Framework

**Phase 1: Planning (Day 1)**
- Define GTA
- Create content outline
- Set up systems

**Phase 2: Creation (Days 2-3)**
- Batch content creation
- Prepare all materials
- Set up automation

**Phase 3: Launch (Day 4)**
- Publish content
- Activate ads
- Begin engagement

**Phase 4: Optimize (Day 5)**
- Analyze metrics
- Adjust targeting
- Scale winners

**Phase 5: Repeat (Tornado Cycle)**
- Document learnings
- Plan next cycle
- Build on previous momentum (snowball effect)
- Continuous improvement with exponential growth

## Second Brain for Marketing

### External Brain System

**Capture:**
- Content ideas
- Customer insights
- Successful posts
- Testimonials

**Organize:**
- By theme
- By platform
- By funnel stage
- By date

**Distill:**
- Best performing content
- Common objections
- Winning formulas
- Customer language

**Express:**
- Create from templates
- Repurpose content
- Build swipe files
- Systematize creation

## Common Objections and Responses

### "It's too expensive"
**Response framework:**
1. Acknowledge
2. Reframe (investment vs cost)
3. Show ROI
4. Offer payment plan
5. Guarantee

### "I need to think about it"
**Response:**
- "What specifically would help you decide?"
- Address concerns
- Urgency/scarcity
- Follow-up plan

### "I've tried this before"
**Response:**
- "What didn't work last time?"
- Differentiate your approach
- Show what's different
- Offer guarantee

## Metrics That Matter

### Traffic Metrics
- Reach
- Impressions
- Website visitors
- Video views

### Engagement Metrics
- Engagement rate
- Comments
- Shares
- Saves

### Conversion Metrics
- Lead conversion rate
- Sales conversion rate
- Average order value
- Customer acquisition cost

### Revenue Metrics
- Total revenue
- Revenue per lead
- Lifetime value
- Return on ad spend

## Success Stories Framework

### Before-After-Bridge Structure

**Before:**
- Describe the struggle
- Make it relatable
- Show the pain

**After:**
- Specific results
- Emotional payoff
- New reality

**Bridge:**
- What made the difference
- Your product/service
- Action they took

## Advanced Tactics

### The iClass Method

**คืออะไร:**
สถาบันที่สอนชื่อ **iClass** หรือ **iClass University** — ทำตามแนวทางและแก่นของ iClass

**หลักการ:**
- สอนตามแนวทางของ iClass University
- เน้นการสร้าง premium positioning
- Expert positioning
- Premium pricing
- Exclusive community
- High-touch service

**ที่มา:**
คอร์ส OTO ถูกพัฒนาโดย iClass University ซึ่งสอนกระบวนการทำ marketing และ sales ตาม framework ที่เรียกว่า OTO (One Time Offer) Framework

**ดูเพิ่มเติม:**
- เว็บไซต์: iClass University (iclassuniversity.mykajabi.com)
- คอร์สที่เกี่ยวข้อง: iClass31 SPEAK TO SELL, OTO Marketing Framework

### Branding by Selling
Every sales interaction builds brand:
- Customer experience
- Post-purchase follow-up
- Success celebration
- Referral generation

### Thank Economy in Practice
1. **Pre-sale:** Give value, build relationship
2. **During sale:** Exceptional experience
3. **Post-sale:** Continued support, appreciation
4. **Ongoing:** Community, recognition, success stories

## Quick Reference Checklists

### Pre-Launch Checklist
- [ ] GTA defined
- [ ] Content calendar ready (30 days)
- [ ] Authority assets prepared
- [ ] Offer stack complete
- [ ] Sales page done
- [ ] Email sequence written
- [ ] Tracking in place
- [ ] Testimonials collected
- [ ] Guarantee prepared
- [ ] CTA strategy planned

### Daily Checklist
- [ ] Morning metrics check
- [ ] Content published
- [ ] Engagement completed
- [ ] Lead follow-up
- [ ] Evening review

### Weekly Checklist
- [ ] Metrics analysis
- [ ] Content performance review
- [ ] CTA optimization
- [ ] Next week's GTA planning
- [ ] Authority content update
