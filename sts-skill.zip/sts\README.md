# STS - Speak To Sell Skill

เทคนิคการขายแบบ 1-to-Many สร้างรายได้หลายล้านจากการขายครั้งเดียว ผ่านการนำเสนอ (Presentation) ที่มัดใจผู้ฟัง

## Overview

STS (Speak To Sell) คือเทคนิคการขายแบบ 1-to-Many ที่ช่วยให้สร้างรายได้หลายล้านจากการขายครั้งเดียว ผ่านการนำเสนอที่มัดใจผู้ฟัง

## What's Included

- **Hook-Frame-How to-Switch-Offer** - 5-Step Framework
- **Module 0** - Mindset & Basic Framework (Hook/Frame/How to/Switch/Offer)
- **Module 1** - Fixed Mindset vs Growth Mindset
- **Module 2** - 5-Step Process + Irresistible Offer
- **Module 3** - The Irresistible Offer (ข้อเสนอที่ไม่อาจปฏิเสธ)
- **Module 4** - Urgency & Scarcity (2 วิธีเพิ่มความสั่นของกระเป๋าสตางค์)
- **Module 5** - Before & After Presentation
- **Module 6** - Content Secret
- **Module 7** - Step 4 - The Offer
- **Module 8** - Hook (ฮุกยังไงให้โดน)
- **Module 10** - Switching (เคล็ดลับการเคาะประตู)

## File Structure

```
sts/
├── SKILL.md                              # Main skill file
├── README.md                             # This file
└── references/                           # Detailed guides
    ├── framework.md                      # High Ticket Speak To Sell Formula
    ├── modules.md                        # Modules 1-10 overview
    ├── module0_transcript.md             # Module 0: Welcome Class
    ├── module3_transcript.md             # Module 3: Irresistible Offer
    ├── module4_transcript.md             # Module 4: Urgency & Scarcity
    ├── module5_transcript.md             # Module 5: Before & After
    ├── module6_transcript.md             # Module 6: Content Secret
    ├── module7_transcript.md             # Module 7: The Offer
    ├── module8_transcript.md             # Module 8: Hook
    └── module10_transcript.md            # Module 10: Switching
```

## Installation

1. Download or clone this repository
2. Copy the entire `sts` folder to your OpenClaw workspace:
   ```
   ~/.openclaw/workspace/skills/sts/
   ```
3. Restart OpenClaw Gateway
4. The skill is now available for use

## Usage

In your OpenClaw session, simply ask about:
- STS framework
- Hook/Frame/How to/Switch/Offer
- Sales presentations
- High-ticket sales
- Live selling techniques
- Creating urgency and scarcity
- Irresistible offers

## Core Framework

### 5-Step Speak To Sell Framework

```
Hook → Frame → How to → Switch → Offer
```

| Step | Name | Description | Example |
|------|------|-------------|---------|
| 1 | **Hook** | ดึงดูดให้คนหยุดฟัง | "5 ขั้นตอนเพิ่มรายได้ 10 เท่า" |
| 2 | **Frame** | ทำให้เห็นว่าปัญหาสำคัญ | เล่าชีวิตตัวเอง, ทำให้รู้สึกว่า "เรื่องนี้เกี่ยวกับกู" |
| 3 | **How to** | ให้คุณค่าจริงที่ใช้ได้ | ให้ 6 ข้อ/5 ขั้นตอน ที่เอาไปทำต่อได้ |
| 4 | **Switch** | เปลี่ยนจากให้ความรู้ → ขาย | "เอาไปลงมือทำได้เลย หลังจากนี้เข้าสู่ช่วงออฟเฟอร์" |
| 5 | **Offer** | เสนอข้อเสนอที่ไม่กล้าปฏิเสธ | ทำให้เห็น Full Price คุ้มค่าก่อน ค่อยลด |

## Key Concepts

### The Irresistible Offer (ข้อเสนอที่ไม่อาจปฏิเสธ)

**3 ขั้นตอนสร้าง Offer ที่มัดใจ:**

1. **ทำให้เห็นว่า Full Price คุ้มค่า** - สร้าง Perceived Value สูงกว่าราคา
2. **ลดราคาในช่วงพิเศษ** - Super-Preorder, Preorder, ช่วงเทศกาล
3. **มี Bonus พิเศษ** - จำกัดเวลา หรือจำกัดจำนวน

### Urgency & Scarcity

| Method | Example | Result |
|--------|---------|--------|
| **Deadline** | Pre-order / Early Bird | กระตุ้นให้ตัดสินใจเร็ว |
| **Event-only** | สมัครใน Live นี้เท่านั้น | สร้างความพิเศษ |
| **Limited quantity** | "2 ชิ้นสุดท้าย" / "10 ท่านแรก" | FOMO |

⚠️ **Result:** Good urgency can increase sales by **200-400%**

### Mindset: Selling is Helping

> "ถ้าสินค้าของคุณช่วยแก้ปัญหาได้จริง การที่คุณไม่พยายามขายให้เขาเลยต่างหากที่เป็นความผิด"

### Switching Technique (เคาะประตู)

**Key Insight:** การสวิตช์ให้สมูทไม่ได้อยู่ที่ประโยคสุดท้าย แต่อยู่ที่ **"การเคาะประตูล่วงหน้า"**

**Example:**
> *"ช่วงท้าย ผมจะมาบอกว่าคลาสใหม่มีอะไร และช่วยประหยัดเวลาให้ยังไงได้บ้าง"*

## When to Use This Skill

Use this skill when you need help with:
- Creating sales content
- Preparing presentations that close deals
- Hook/Frame techniques for Live/Video
- Increasing conversion rates from group sales
- High-ticket sales through presentations
- Creating offers that customers can't refuse

## Best Practices

1. **Don't fear selling** - If you believe in your product, selling is helping
2. **Practice often** - The more you speak, the smoother you get
3. **Know your audience** - Understand real pain points
4. **Create value first** - Give real value before selling
5. **Have clear Call to Action** - Tell customers what to do next
6. **Presentation skills matter** - Good product + bad presentation = no sales

## Related Skills

- [OTO Marketing Framework](../oto) - One Time Offer strategy

## Credits

Based on the Speak To Sell (STS) methodology for high-ticket sales presentations.

## License

This skill is provided as-is for educational and practical use with OpenClaw AI agents.
