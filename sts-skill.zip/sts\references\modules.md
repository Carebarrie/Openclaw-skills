# STS Modules Reference

รายละเอียดเนื้อหาแต่ละ Module จากคอร์ส iClass31: SPEAK TO SELL

---

## Pre-Class

### High Ticket Speak To Sell Formula
**5 ขั้นตอนสร้างเงิน (หลาย) ล้าน จากการขายแค่ครั้งเดียว**

เนื้อหาพื้นฐานสำคัญก่อนเข้าบทเรียนหลัก อธิบายกรอบคิดทั้ง 5 ขั้นตอนของ STS

---

## Module 1: The Biggest Enemy

### ศัตรูหมายเลข 1 ที่ทำให้ STS ไม่ได้ผล

**เนื้อหาหลัก:**
- ความกลัว (Fear) ในการขาย
- Limiting beliefs เกี่ยวกับการขาย
- Imposter syndrome
- กลัวถูกปฏิเสธ (Fear of rejection)

**วิธีเอาชนะ:**
- Reframe การขายเป็นการช่วยเหลือ
- สร้างความมั่นใจจากการรู้จักสินค้าจริงๆ
- Practice mindset shift

---

## Module 2: The First Step

### ขั้นตอนแรกของ STS + 4 Levels of Selling

**เนื้อหาหลัก:**
- การเตรียมตัวก่อนลงสนาม
- รู้จักกลุ่มเป้าหมาย (Audience Analysis)
- เข้าใจ Customer Journey
- การตั้งโจทย์ที่ชัดเจน

**4 Levels of Selling:**

| Level | ลักษณะ |
|-------|--------|
| **Level 4** | ความรู้ (มีสคริปต์) + การขาย พูดคล่องมาก มีสคริปต์เยอะ (หายาก 3-4 คน) |
| **Level 3** | ความรู้ (มีสคริปต์) + การขาย |
| **Level 2** | ความรู้ + การขาย |
| **Level 1** | ขายตรงอย่างเดียว |

**Key Takeaways:**
- ไม่ควรเริ่มสร้าง Content ก่อนรู้จักลูกค้า
- Pain point ที่ลึกซึ้งคือกุญแจสำคัญ
- โครงสร้างที่ดีช่วยให้สร้างเนื้อหาง่ายขึ้น
- **Presentation Skills สำคัญมาก** - ถ้าของดีแต่พูดไม่ดี ก็ขายไม่ได้

---

## Module 3: วิธีทำให้ Full Price คุ้มค่า (Deep Dive)

### การ Position ราคาให้สมเหตุสมผล + The Irresistible Offer

**เนื้อหาหลัก:**
- Value-based pricing vs Cost-based pricing
- การสร้าง Perceived value
- วิธีนำเสนอราคาให้ดูคุ้มค่า
- การเปรียบเทียบกับต้นทุนอะไรๆ

**The Irresistible Offer (3 ขั้นตอน):**

1. **ทำให้เห็นว่า Full Price คุ้มค่า**
   - สร้าง Perceived Value สูงกว่าราคา
   - เปรียบเทียบกับต้นทุนอื่น
   - ROI calculation

2. **ลดราคาในช่วงพิเศษ**
   - Super-Preorder
   - Preorder
   - ช่วงเทศกาล (New Year)
   - Event เฉพาะทาง

3. **มี Bonus พิเศษ (จำกัดเวลา/จำนวน)**

**Techniques:**
- ROI calculation
- Cost of inaction
- Comparison with alternatives
- Value stacking

---

## Module 4: 2 วิธีเพิ่มความสั่นของกระเป๋าสตางค์

### ทำให้อยากซื้อมากขึ้น

**วิธีที่ 1: Scarcity (ความหายาก)**
- จำกัดจำนวน
- จำกัดเวลา
- จำกัดสิทธิพิเศษ

**วิธีที่ 2: Urgency (ความเร่งด่วน)**
- ราคาจะขึ้น
- โอกาสจะหมดไป
- ปัญหาจะแย่ลงถ้าไม่แก้ตอนนี้

**Warning:** ใช้ ethically อย่าโกหก

---

## Module 5: Killer Bonus

### Bonus ที่ทำให้กระเป๋าสตางค์สั่น

**ประเภทของ Killer Bonus:**

1. **Fast Action Bonus**
   - สำหรับคนตัดสินใจเร็ว
   - มีจำนวนจำกัดมาก
   - มูลค่าสูง

2. **Exclusive Bonus**
   - หาไม่ได้ที่อื่น
   - เฉพาะในนี้เท่านั้น
   - สร้าง uniqueness

3. **High-Value Bonus**
   - มูลค่ารวม Bonus > ราคาขาย
   - คำนวณให้เห็นชัดเจน

**การ Present Bonus:**
- เปิดเผยทีละอันเพื่อสร้าง excitement
- อธิบายคุณค่าของแต่ละ Bonus
- แสดงราคารวมทั้งหมด

---

## Module 6: Content Secret (EP.1)

### ความลับของ Content (เพื่อขาย) ที่คนส่วนมากไม่รู้

**เนื้อหาหลัก:**
- ความแตกต่างระหว่าง Content ให้คุณค่า vs Content ขาย
- Content structure ที่นำไปสู่การขาย
- จังหวะในการใส่ Call to Action
- การสร้าง Desire ผ่านเนื้อหา

**ความเชื่อมั่น (Trust):**
- ถ้าลูกค้าเชื่อมั่นในตัวเรา จะซื้อง่ายขึ้น
- ถ้ายังไม่ซื้อ แปลว่าอาจ "มีข้อมูลไม่มากพอ"
- ต้องให้ข้อมูลเพิ่มจนกว่าจะมั่นใจ

**Key Secrets:**
- Teach what, sell how
- ให้ Aha moment แต่ไม่ให้ทุกอย่าง
- สร้างความอยากได้มากขึ้นเรื่อยๆ

---

## Module 7: Content Secret (Advance) (EP.2)

### ความลับของ Content (ขั้น Advance) + How-to Content

**เนื้อหาขั้นสูง:**
- Advanced content sequencing
- การใช้ Storytelling ในการขาย
- Pattern interrupt เพื่อดึงความสนใจกลับมา
- การสร้าง Epiphany ให้ผู้ฟัง

**How-to Content ใน STS:**
- ทำหน้าที่ให้ความรู้ที่ปฏิบัติได้
- สร้างความเชื่อมั่นว่าเรารู้จริง
- เป็นขั้นตอนก่อนไปสู่ Offer

**Advanced Techniques:**
- Open loop
- Nested story
- Callback
- Future pacing

---

## Module 8: Hook อย่างไร ให้โดน

### ศิลปะของการ Hook

**Hook คือ:** "สิ่งที่ดึงดูดความสนใจ" เพื่อให้คนมาฟังเรา

**ประเภทของ Hook:**

1. **Question Hook** - ถามคำถามที่ทำให้คิด
2. **Story Hook** - เริ่มด้วยเรื่องราวที่น่าสนใจ
3. **Stat Hook** - ใช้ตัวเลขที่ช็อก
4. **Contrarian Hook** - ไปตรงกับความเชื่อทั่วไป
5. **Benefit Hook** - โชว์ผลประโยชน์ทันที

**ตัวอย่างการใช้:**
- เปิดด้วยเรื่องราวที่น่าสนใจ
- ใช้รูปภาพที่ดึงดูด (เช่น ตัวอย่างใน slide ใช้รูป David Beckham)
- สร้างความอยากรู้อยากเห็นในทันที

**Hook Formula:**
```
[Hook] + [Promise] + [Credibility] = Attention Captured
```

---

## Module 9: Frame ให้เห็นว่าสำคัญ

### การกำหนดกรอบความคิด

**3 Frames หลัก:**

1. **Problem Frame**
   - ทำให้เห็นว่าปัญหาร้ายแรง
   - ขยาย Pain ให้ชัดเจน
   - สร้าง Urgency

2. **Solution Frame**
   - ตั้งตัวเป็นผู้เชี่ยวชาญ
   - แสดง Credibility
   - ให้ความหวัง

3. **Opportunity Frame**
   - เปิดโอกาสใหม่
   - ทำให้เห็นภาพอนาคตที่ดีขึ้น
   - สร้าง Desire

---

## Module 10: Switching ให้ Smooth

### เปลี่ยนจากเนื้อหาสู่การขายอย่างเป็นธรรมชาติ

**The Challenge:**
- อย่าให้รู้สึกว่ากำลังโดนขาย
- รักษา Energy ที่ดีไว้
- สร้าง Momentum ให้ตัดสินใจ

**Switching Techniques:**

1. **The Bridge**
   - "ตอนนี้คุณรู้แล้วว่า... แต่นั่นเป็นแค่ส่วนหนึ่ง..."

2. **The Tease**
   - "ถ้าคุณอยากได้ผลลัพธ์จริงจัง ผมมีสิ่งที่ช่วยคุณได้..."

3. **The Natural Progression**
   - "จากที่พูดมา ขั้นต่อไปคือ..."

4. **The Story Transition**
   - เล่าเรื่องราวที่นำไปสู่ Offer

---

## Special Bonus

### STS Examples

ตัวอย่างการใช้ STS จากคลาสจริง:

1. **iClass12 PLUS** - ต้นฉบับการใช้ STS
2. **iClass23: EXPERT BUSINESS** - รุ่นพิเศษ 2
3. **OTO2021: ONLINE TAKE OVER MASTERCLASS 2021**
4. **BIG LEAP 202x** - โตปีนี้แบบก้าวกระโดด

### Post Marketing
**วิธีเพิ่มยอดขาย 2-10 เท่าด้วย STS เดียว**

- การติดตามหลัง Live
- Retargeting คนที่ดูแต่ไม่ซื้อ
- สร้าง FOMO หลังจากนั้น

### Pre-Marketing
**วิธีทำให้คนมารอดู STS เยอะๆ**

- Teaser content strategy
- Event creation
- Reminder system
- Group engagement

---

## Key Formulas Summary

### การขาย (Selling)
```
การสื่อสาร/โน้มน้าว → ลูกค้าเชื่อในคุณค่า & ความคุ้มค่า → ยอมเสียเงินแลกอย่างเต็มใจ
```

### The Irresistible Offer
```
Full Price Value (ดูคุ้มค่า) + ส่วนลดช่วงพิเศษ + Bonus จำกัด = ข้อเสนอที่ไม่กล้าปฏิเสธ
```

### STS Content Flow
```
Hook (ดึงดูด) → Frame (กำหนดกรอบ) → Content (ให้คุณค่า) → Switch (เปลี่ยนสู่การขาย) → Close (ปิดการขาย)
```
